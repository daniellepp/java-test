public class DataTypes {
    public static void main(String[] args) {
        int number = 25;
        Integer numberObj = Integer.valueOf(25);
        String text = "25";

        System.out.println("int: " + number);
        System.out.println("Integer: " + numberObj);
        System.out.println("String: " + text);
    }
}
