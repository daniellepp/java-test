# Java Test Answers (Questions 1–5)

This repository contains answers to basic Java programming questions, including code files and outputs.

## Contents

- `Q1_HelloWorld.java` - Prints "Hello, World!"
- `Q2_EqualsVsDoubleEquals.java` - Shows difference between == and .equals()
- `Q3_MainMethod.java` - Explains the main method in Java
- `Q4_AddTwoNumbers.java` - Adds two numbers entered by the user
- `Q5_DataTypes.java` - Demonstrates int, Integer, and String

Each program has a corresponding output file in the `/outputs` folder.
