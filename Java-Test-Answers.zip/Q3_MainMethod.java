public class MainMethodExample {
    public static void main(String[] args) {
        System.out.println("This is the starting point of the program.");
    }
}
